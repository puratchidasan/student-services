echo 'Testing ansible version on be-s3133-msl...'
ansible --version

echo 'Testing ansible-playbook version on be-s3133-msl...'
ansible-playbook --version